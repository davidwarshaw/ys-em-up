<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="ys_ii_tileset_extruded" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="16" columns="4">
 <image source="ys_ii_tileset_extruded.png" width="72" height="72"/>
</tileset>
